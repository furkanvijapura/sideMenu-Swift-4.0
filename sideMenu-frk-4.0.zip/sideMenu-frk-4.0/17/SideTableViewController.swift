//
//  SideTableViewController.swift
//  17
//
//  Created by Discus IT on 22/08/17.
//  Copyright © 2017 Discus IT. All rights reserved.
//

import UIKit

enum LeftMenu: Int {
    case main = 0
    case share
    case bin
    case contact
    case timesheet
    case Opportunity
    case product
    case settings
    case logout
    
}

protocol LeftMenuProtocol : class
{
    func changeViewController(_ menu: LeftMenu)
}


class SideTableViewController: UITableViewController,LeftMenuProtocol
{

    var menus = ["Dashboard", "Salse", "Visits","Contact","Timesheet","Opportunity","Product","Setting","Logout"]
    var mainViewController: UIViewController!
    
    var shareViewController : UIViewController!
    var binViewController: UIViewController!
    var contact: UIViewController!
    var timesheet: UIViewController!
    var opportunity: UIViewController!
    var product: UIViewController!
    var setting: UIViewController!
    var logout: UIViewController!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        tableView.register(UINib.init(nibName: "HeaderViewCell1", bundle: nil), forCellReuseIdentifier: "HeaderView1")
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let shareViewController = storyboard.instantiateViewController(withIdentifier: "shareViewController") as! shareViewController
        self.shareViewController = UINavigationController(rootViewController: shareViewController)
        
        let BinViewController = storyboard.instantiateViewController(withIdentifier: "BinViewController") as! BinViewController
        self.binViewController = UINavigationController(rootViewController: BinViewController)
        
        let contactViewController = storyboard.instantiateViewController(withIdentifier: "contacts") as! contacts
        self.contact = UINavigationController(rootViewController: contactViewController)
        
        let TimesheetViewController = storyboard.instantiateViewController(withIdentifier: "timesheet") as! timesheet
        self.timesheet = UINavigationController(rootViewController: TimesheetViewController)
        
        let OppoertunityViewController = storyboard.instantiateViewController(withIdentifier: "opportunity") as! opportunity
        self.opportunity = UINavigationController(rootViewController: OppoertunityViewController)
        
        let ProductViewController = storyboard.instantiateViewController(withIdentifier: "product") as! product
        self.product = UINavigationController(rootViewController: ProductViewController)
        
        let settingViewController = storyboard.instantiateViewController(withIdentifier: "setting") as! setting
        self.setting = UINavigationController(rootViewController: settingViewController)
        
        let logoutViewController = storyboard.instantiateViewController(withIdentifier: "logout") as! logout
        self.logout = UINavigationController(rootViewController: logoutViewController)

    }
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewDidAppear(animated)
    }


    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func changeViewController(_ menu: LeftMenu) {
        switch menu
        {
        case .main:
            self.slideMenuController()?.changeMainViewController(self.mainViewController, close: true)
        case .share:
            self.slideMenuController()?.changeMainViewController(self.shareViewController, close: true)
        case .bin:
            self.slideMenuController()?.changeMainViewController(self.binViewController, close: true)
        case .contact:
            self.slideMenuController()?.changeMainViewController(self.contact, close: true)
        case .timesheet:
            self.slideMenuController()?.changeMainViewController(self.timesheet, close: true)
        case .Opportunity:
            self.slideMenuController()?.changeMainViewController(self.opportunity, close: true)
        case .product:
            self.slideMenuController()?.changeMainViewController(self.product, close: true)
        case .settings:
            self.slideMenuController()?.changeMainViewController(self.setting, close: true)
        case .logout:
            self.slideMenuController()?.changeMainViewController(self.logout, close: true)
            
        default: break
        }
    }


    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return menus.count
    }

 
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let menu = LeftMenu(rawValue: indexPath.row)
        {
            switch menu
            {
            case .main, .share, .bin, .contact, .timesheet, .Opportunity, .product, .settings, .logout:
        
                let cell = tableView.dequeueReusableCell(withIdentifier: "BaseTableViewCell", for: indexPath)

               // cell.textLabel?.text = menus[indexPath.row]
                let cellImg : UIImageView = UIImageView(frame: CGRect(x: 8, y: 11, width: 40, height: 40))
                cellImg.image = UIImage(named: "radioDemo")
                cell.addSubview(cellImg)
                
                let lblCell : UILabel = UILabel(frame: CGRect(x: 70, y: 17, width: 300, height: 30))
                lblCell.adjustsFontSizeToFitWidth = true
                lblCell.minimumScaleFactor = 0.2
                lblCell.font = UIFont.systemFont(ofSize: 20.0)
                lblCell.textColor = UIColor.white
                lblCell.text = menus[indexPath.row]
                cell.addSubview(lblCell)
                return cell
            }
        }
        return UITableViewCell()
        
    }
   
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let menu = LeftMenu(rawValue: indexPath.row) {
            self.changeViewController(menu)
        }
    }
    
    override func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        if self.tableView == scrollView
        {
            
        }
    }
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let HeaderCell =  tableView.dequeueReusableCell(withIdentifier: "HeaderView1")as! HeaderViewCell1
        
        return HeaderCell
    }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 189.0
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70.0
    }




}
