//
//  HeaderViewCell.swift
//  GreenBox
//
//  Created by Discus IT on 14/08/17.
//  Copyright © 2017 Discus IT. All rights reserved.
//

import UIKit

class HeaderViewCell1: UITableViewCell {

    @IBOutlet weak var user_profile_image: UIImageView!
    @IBOutlet weak var btn_setting: UIButton!
    @IBOutlet weak var lbl_email_id: UILabel!
    @IBOutlet weak var lbl_username: UILabel!
    @IBOutlet weak var view: UIView!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
      
    
    }

    @IBAction func setting_action(_ sender: UIButton)
    {
        
    }
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
