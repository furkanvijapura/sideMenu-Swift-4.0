//
//  BinViewController.swift
//  17
//
//  Created by Discus IT on 22/08/17.
//  Copyright © 2017 Discus IT. All rights reserved.
//

import UIKit

class BinViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
self.setNavigationBarItem()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func Main_action(_ sender: UIButton)
    {
        let main = storyboard?.instantiateViewController(withIdentifier: "MainViewController")as! MainViewController
        self.navigationController?.pushViewController(main, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
